-- Função para desenhar o texto 3D
function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

-- Função para criar o NPC e ajustá-lo ao solo
local function createNPC(model, coords, heading)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(1)
    end

    -- Ajusta a coordenada Z para o solo
    local groundZ
    local foundGround, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z, false)

    if foundGround then
        coords = vector3(coords.x, coords.y, groundZ)
    end

    local npc = CreatePed(4, model, coords.x, coords.y, coords.z, heading, false, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    FreezeEntityPosition(npc, true)
    
    if DoesEntityExist(npc) then
        print("NPC criado com sucesso!")
    else
        print("Erro ao criar NPC.")
    end
    return npc
end

-- Coordenadas e diálogos dos NPCs
local npcLocations = {
    {model = "a_m_m_farmer_01", coords = vector3(215.45, -810.29, 30.73), heading = 90.0},
    {model = "a_f_m_bevhills_01", coords = vector3(220.45, -805.29, 30.73), heading = 270.0},
    {model = "a_m_m_business_01", coords = vector3(-429.3, 1120.45, 325.85), heading = 100.0}
}

-- Criação dos NPCs e referência para cada NPC
local npcEntities = {}

Citizen.CreateThread(function()
    for _, npcData in pairs(npcLocations) do
        local npc = createNPC(GetHashKey(npcData.model), npcData.coords, npcData.heading)
        table.insert(npcEntities, {npc = npc, data = npcData})
    end
end)

-- Exibir o texto quando o jogador se aproximar do NPC e permitir a interação
Citizen.CreateThread(function()
    while true do
        Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        for _, npcEntity in pairs(npcEntities) do
            local npcCoords = npcEntity.data.coords
            local distance = #(playerCoords - npcCoords)

            if distance < 5.0 then
                DrawText3D(npcCoords.x, npcCoords.y, npcCoords.z + 1.0, "[E] Oi, está gostando do jogo?")
                if IsControlJustReleased(1, 38) then  -- 38 é a tecla "E"
                    TriggerEvent('npc:startConversation', npcEntity.npc)
                end
            end
        end
    end
end)

-- Função para reproduzir som de arquivo externo
function PlayNPCSound(soundName)
    SendNUIMessage({
        transactionType = 'playSound',
        transactionFile = soundName,
        transactionVolume = 1.0  -- Ajuste o volume se necessário
    })
end

-- Evento de interação quando o jogador aperta "E"
RegisterNetEvent('npc:startConversation')
AddEventHandler('npc:startConversation', function(npc)
    print("Iniciando conversa com o NPC...")

    -- Reproduz o arquivo de som externo (arquivo 'npc_voice.wav')
    PlayNPCSound("npc_voice.wav")

    -- Após a interação, o NPC realiza outra animação e começa a andar
    ClearPedTasksImmediately(npc)
    TaskStartScenarioInPlace(npc, "WORLD_HUMAN_SMOKING", 0, true)
    Wait(5000)
    FreezeEntityPosition(npc, false)
    TaskWanderStandard(npc, 1.0, 1)
end)
