fx_version 'cerulean'
game 'gta5'

files {
    'sounds/npc_voice.wav',
    'html/index.html'
}

ui_page 'html/index.html'

client_scripts {
    'client/npc_talk.lua'
}
